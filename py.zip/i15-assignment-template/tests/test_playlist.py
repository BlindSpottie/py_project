from music_analyzer import MusicAnalyzer
from music_library import MusicLibrary
from playlist import Playlist
from track import Track

""" You must extend this file into a comprehensive suite covering normal cases, edge
cases, and invalid input. Do not rename or move this file."""

def make_track(track_id="t", artists="A", mood="Happy", popularity=50, duration_ms=200000, danceability=0.5):
    """Build a Track, varying only the fields the statistics tests rely on."""
    return Track(track_id, artists, "Song", "Pop", mood, "Medium", danceability, 0.5, 0.5, 120.0, -5.0, 0.5, duration_ms, popularity)

def test_total_duration_sums_all_tracks():
    """total_duration is the sum of every track's duration_ms."""
    playlist = Playlist([make_track(duration_ms=200000), make_track(duration_ms=100000)])
    assert playlist.total_duration() == 300000
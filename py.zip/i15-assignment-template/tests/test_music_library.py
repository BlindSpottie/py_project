from music_library import MusicLibrary
import csv

""" You must extend this file into a comprehensive suite covering normal cases, edge
cases, and invalid input. Do not rename or move this file."""

HEADER = ["track_id", "artists", "track_name", "genre", "mood", "duration_category",
          "danceability", "energy", "valence", "tempo", "loudness", "acousticness",
          "duration_ms", "popularity"]

VALID_ROW = ["4yNk9iz9WVJikRFle3XEvn", "JVKE", "golden hour", "Pop", "Sad", "Medium",
             "0.515", "0.593", "0.153", "94.467", "-4.801", "0.653", "209259", "66"]


def test_init_creates_empty_library():
    """A new MusicLibrary starts with no tracks."""
    library = MusicLibrary()
    assert len(library) == 0
    assert library.tracks == []

def write_csv(tmp_path, rows, header=HEADER):
    """Write a temporary CSV file and return its path."""
    path = tmp_path / "tracks.csv"

    with open(path, "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(header)
        writer.writerows(rows)

    return str(path)

def test_load_from_csv_loads_a_valid_row(tmp_path):
    """A well-formed row is loaded into the library."""
    library = MusicLibrary()
    library.load_from_csv(write_csv(tmp_path, [VALID_ROW]))

    assert len(library) == 1
    assert library.tracks[0].track_name == "golden hour"



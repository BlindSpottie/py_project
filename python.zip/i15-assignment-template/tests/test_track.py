from track import Track

#py -m pytest tests/test_track.py -s

""" You must extend this file into a comprehensive suite covering normal cases, edge
cases, and invalid input. Do not rename or move this file."""

#This is a track from the CSV file
def make_track(track_id="4yNk9iz9WVJikRFle3XEvn", artists="JVKE", track_name="golden hour", genre="Pop"):
    """Build a sample Track object with fixed defaults for fields, so each test does not need to repeat for all 14 fields."""
    return Track(track_id, artists, track_name, genre, "Sad", "Medium",0.515, 0.593, 0.153, 94.467, -4.801, 0.653, 209259, 66)

#       audio_features()

def test_audio_features_returns_expected_dictionary():
    """audio_features returns the six audio features with their correct values."""
    features = make_track().audio_features()
    # print(features)
    assert features == {
        "danceability": 0.515,
        "energy": 0.593,
        "valence": 0.153,
        "tempo": 94.467,
        "loudness": -4.801,
        "acousticness": 0.653,
    }

#       artists_names()

def test_artists_names():
    """artist_names returns the indivudual artists who performed the track as list of strings."""

    result = make_track().artist_names()
    track_in_example = make_track(artists="Calvin Harris;Dua Lipa;Oliver Heldens")
    assert result == ["JVKE"]
    assert track_in_example.artist_names() == ["Calvin Harris","Dua Lipa","Oliver Heldens"]

def test_artists_names_empty():
    track = make_track(artists="")

    try:
        track.artist_names()
    except ValueError:
        assert True
    else:
        False, "Expected ValueError, but there is none"

def test_str_no_spaces_in_artist_names():
    """pytest to check is there's no leading or trailing white spaces"""
    no_space = make_track(artists=" Michael Jackson   ;   Drake  ").artist_names() 
    assert no_space == ["Michael Jackson", "Drake"], "There are still some leading or trailing spaces!" #AssertionError

#       __str__()

def test_string_track():
    """pytest to test if the string output is correct"""
    result_str = make_track().__str__()
    # print(result_str)
    assert result_str == "TrackID: 4yNk9iz9WVJikRFle3XEvn, Title: golden hour, Artist: JVKE, Genre: Pop", "str output is not correct!"

def test_string_track_empty():
    """test string output if track title is empty"""
    result_str = make_track(track_name="").__str__()
    assert result_str == "TrackID: 4yNk9iz9WVJikRFle3XEvn, Title: , Artist: JVKE, Genre: Pop", "str output is not correct!"

def test_str_more_artists():
    """ 
    Checks if __str__ is still valid for csv line with multiple artists.
    __str__ should return artists exactly as stored, so with semicolon.
    """
    example_track_02 = make_track(
        track_id = "3gE4eQH3K83Sght0ZLvuBK",
        artists = "Bad Bunny;Drake",
        track_name = "MIA",
        genre = "Latin"
    )

    new_track_01 = make_track(
        track_id ="2V4bv1fNWfTcyRJKmej6Sj",
        artists = "Mike Posner;Gigamesh",
        track_name = "Cooler Than Me - Single Mix",
        genre = "Electronic"
    )
    
    assert new_track_01.__str__() == "TrackID: 2V4bv1fNWfTcyRJKmej6Sj, Title: Cooler Than Me - Single Mix, Artist: Mike Posner;Gigamesh, Genre: Electronic", "Output is not correct!"
    assert example_track_02.__str__() == "TrackID: 3gE4eQH3K83Sght0ZLvuBK, Title: MIA, Artist: Bad Bunny;Drake, Genre: Latin", "output 2 is not correct!"

    #2V4bv1fNWfTcyRJKmej6Sj,
    # Mike Posner;Gigamesh,
    # Cooler Than Me - Single Mix,
    # Electronic,
    # Neutral,
    # Medium,
    # 0.768,
    # 0.82,
    # 0.625,
    # 129.965,
    # -4.63,
    # 0.179,
    # 213293,
    # 76
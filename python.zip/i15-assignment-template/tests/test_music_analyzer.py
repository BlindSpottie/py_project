import pytest
from music_analyzer import MusicAnalyzer
from music_library import MusicLibrary
from track import Track

""" You must extend this file into a comprehensive suite covering normal cases, edge
cases, and invalid input. Do not rename or move this file."""

def make_track(track_id, danceability, energy, valence, tempo, loudness, acousticness):
    """build a track with the given data"""
    return Track(
        track_id=track_id,
        artists="Artist",
        track_name="Name",
        genre="Pop",
        mood="Happy",
        duration_category="Medium",
        danceability=danceability,
        energy=energy,
        valence=valence,
        tempo=tempo,
        loudness=loudness,
        acousticness=acousticness,
        duration_ms=200000,
        popularity=50,)


def make_track_analyzer():
    library = MusicLibrary()
    library.tracks.append(make_track("a", 0.2, 0.2, 0.2, 100.0, -10.0, 0.2))
    library.tracks.append(make_track("b", 0.8, 0.8, 0.8, 140.0, -5.0, 0.8))
    # library.tracks.append(make_track("c", 0.9, 0.8, 0.8, 140.0, -5.0, 0.8))
    return MusicAnalyzer(library)

def test_init_stores_library():
    """__init__ keeps a reference to the provided library."""
    library = MusicLibrary()
    assert MusicAnalyzer(library).library is library

def test_normalized_features_unknown_track_raises():
    """An unknown track_id raises ValueError."""
    with pytest.raises(ValueError):
        MusicAnalyzer(MusicLibrary()).normalized_features("does_not_exist")
 
def test_distance():
    analyzer = make_track_analyzer()
    assert analyzer.distance("a","b") == pytest.approx(6**0.5), "Output not correct"
    
def test_feature_ranges():
    analyzer = make_track_analyzer()
    ranges = analyzer.feature_ranges()
    assert ranges["danceability"] == (0.2, 0.8)

def test_recommend():
    library = MusicLibrary()
    library.tracks.append(make_track("a", 0.1, 0.1, 0.1, 100.0, -10.0, 0.1))
    library.tracks.append(make_track("b", 0.2, 0.2, 0.2, 105.0, -9.0, 0.2))
    library.tracks.append(make_track("c", 0.9, 0.9, 0.9, 180.0, -2.0, 0.9))
    
    analyzer = MusicAnalyzer(library)
    recommend_track = analyzer.recommend("a", 1)
    assert len(recommend_track) == 1
    assert recommend_track[0][0] == "b"
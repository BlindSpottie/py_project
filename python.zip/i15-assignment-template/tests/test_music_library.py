from music_library import MusicLibrary
import csv

""" You must extend this file into a comprehensive suite covering normal cases, edge
cases, and invalid input. Do not rename or move this file."""

HEADER = ["track_id", "artists", "track_name", "genre", "mood", "duration_category",
          "danceability", "energy", "valence", "tempo", "loudness", "acousticness",
          "duration_ms", "popularity"]

VALID_ROW = ["4yNk9iz9WVJikRFle3XEvn", "JVKE", "golden hour", "Pop", "Sad", "Medium",
             "0.515", "0.593", "0.153", "94.467", "-4.801", "0.653", "209259", "66"]


def test_init_creates_empty_library():
    """A new MusicLibrary starts with no tracks."""
    library = MusicLibrary()
    assert len(library) == 0
    assert library.tracks == []
    

def write_csv(tmp_path, rows, header=HEADER):
    """Write a temporary CSV file and return its path."""
    path = tmp_path / "tracks.csv"

    with open(path, "w", newline="", encoding="utf-8") as csv_file:
        writer = csv.writer(csv_file)
        writer.writerow(header)
        writer.writerows(rows)

    return str(path)

def test_load_from_csv_loads_a_valid_row(tmp_path):
    """A well-formed row is loaded into the library."""
    library = MusicLibrary()
    library.load_from_csv(write_csv(tmp_path, [VALID_ROW]))

    assert len(library) == 1
    assert library.tracks[0].track_name == "golden hour"

def test_invalid_value(tmp_path):
    invalid_row = VALID_ROW.copy()
    invalid_row[3] = "Hardcore"
    library = MusicLibrary()
    csv_path = write_csv(tmp_path, [invalid_row])
    library.load_from_csv(csv_path)

    assert len(library) == 0 , "does not exist! Should be 0"

def test_return_correct_track(tmp_path):
    """checks if get_track() returns the correct track_id"""
    library = MusicLibrary()
    csv_path = write_csv(tmp_path, [VALID_ROW])
    library.load_from_csv(csv_path)

    track = library.get_track("4yNk9iz9WVJikRFle3XEvn")
    assert track is not None
    assert track.track_name == "golden hour"

def test_normalize_header(tmp_path):
    """checks if header is correctly normalized"""
    custom_header = ["Track ID", "Artists",
    "Track-Name", "genre",
    "mood","duration_category",
    "danceability", "energy",
    "valence", "tempo",
    "loudness", "acousticness",
    "duration_ms", "popularity"]
    library = MusicLibrary()
    csv_path = write_csv(tmp_path, [VALID_ROW],header=custom_header)
    library.load_from_csv(csv_path)

    assert len(library) == 1
    assert library.tracks[0].track_name == "golden hour"

def test_capital(tmp_path):
    custom_row = VALID_ROW.copy()
    custom_row[3] = "hip-hop" #genre needs to be 'Hip-Hop'
    custom_row[4] = "hAppy" #mood needs to be 'Happy'
    custom_row[5] = "short" #duration_category needs to be 'Short' 
    library = MusicLibrary()
    csv_path = write_csv(tmp_path,[custom_row])
    library.load_from_csv(csv_path)
    assert len(library) == 1
    assert library.tracks[0].genre == "Hip-Hop"
    assert library.tracks[0].mood == "Happy"
    assert library.tracks[0].duration_category == "Short"


def test_boundries(tmp_path):
    """this tests the minimum or maximum values, so if the boundries are correct"""
    custom_row = VALID_ROW.copy()
    custom_row[6] = "0.0" 
    custom_row[7] = "1.0"
    custom_row[13] = "0"
    library = MusicLibrary()
    csv_path = write_csv(tmp_path, [custom_row])
    library.load_from_csv(csv_path)

    assert len(library) == 1
    assert library.tracks[0].danceability == 0.0
    assert library.tracks[0].energy == 1.0
    assert library.tracks[0].popularity == 0

def test_boundries_out_range(tmp_path):
    """checks for values outside the boundries"""
    invalid_row = VALID_ROW.copy()
    invalid_row[13] = "105" #max = 100

    library = MusicLibrary()
    csv_path = write_csv(tmp_path, [invalid_row])
    library.load_from_csv(csv_path)

    assert len(library) == 0 

def test_invalid_type(tmp_path):
    invalid_row = VALID_ROW.copy()
    invalid_row[6] = "string"

    library = MusicLibrary()
    csv_path = write_csv(tmp_path, [invalid_row])
    library.load_from_csv(csv_path)

    assert len(library) == 0

def test_duplicate_skip(tmp_path):
    """checks if the duplicate rows gets skipped"""
    row_1 = VALID_ROW.copy()
    row_1[2] = "Cooler Than Me"
    row_2 = VALID_ROW.copy()
    row_2[2] = "Cooler Than Me"
    library = MusicLibrary()
    csv_path = write_csv(tmp_path, [row_1,row_2])
    library.load_from_csv(csv_path)

    assert len(library) == 0 #both rows needs to be skipped


def test_get_track_unknown_returns_none(tmp_path):
    """checks if get_track returns None for invalid track_id"""
    library = MusicLibrary()
    csv_path = write_csv(tmp_path, [VALID_ROW])
    library.load_from_csv(csv_path)

    assert library.get_track("132random123") is None
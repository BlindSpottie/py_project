"""
Add the required parameters, type hints, meaningful docstrings, and implementation
according to the assignment specification.
"""

class Track:

    def __init__( 
        self,
        track_id:str,
        artists:str,
        track_name:str,
        genre:str,
        mood:str,
        duration_category:str,
        danceability:float,
        energy:float,
        valence:float,
        tempo:float,
        loudness:float,
        acousticness:float,
        duration_ms:int,
        popularity:int
        ) -> None:
        self.track_id:str = track_id    
        self.artists:str = artists
        self.track_name:str = track_name
        self.genre:str = genre
        self.mood:str = mood
        self.duration_category:str = duration_category
        self.danceability:float = danceability
        self.energy:float = energy
        self.valence:float = valence
        self.tempo:float = tempo
        self.loudness:float = loudness
        self.acousticness:float = acousticness
        self.duration_ms:int = duration_ms
        self.popularity:int = popularity
        # raise NotImplementedError 

    def __str__(self) -> str:
        """ 
        This function gives information in some given format for given song.
        :param self: the object itself
        Returns a string.
        """
        return f"TrackID: {self.track_id}, Title: {self.track_name}, Artist: {self.artists}, Genre: {self.genre}"
        # raise NotImplementedError

    def artist_names(self) -> list[str]:
        """
        This function takes the artist(s) of a given track and puts them in a list as a string.
        :param self: the object itself
        Returns a list with strings inside of it.
        """
        return [artist.strip() for artist in self.artists.split(";")]

    def audio_features(self) -> dict[str, float]:
        """
        This function puts to the discriptors a certain value, such as a str or float.
        :param self: the object itself.

        Returns the track's six numeric audio discriptors as a dictionary each feature name to its value.
        """
        return {
            "danceability": self.danceability,
            "energy": self.energy,
            "valence": self.valence,
            "tempo": self.tempo,
            "loudness": self.loudness,
            "acousticness": self.acousticness
        }
